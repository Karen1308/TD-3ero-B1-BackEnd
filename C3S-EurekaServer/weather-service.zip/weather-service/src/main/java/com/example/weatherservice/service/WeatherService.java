package com.example.weatherservice.service;

public interface WeatherService {
    Integer getWeather(String city, String country);
}
